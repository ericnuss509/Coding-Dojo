﻿using System;

namespace SecondCSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            string place = "Dojo";
            Console.WriteLine($"Hello{place}");
        }
    }
}
