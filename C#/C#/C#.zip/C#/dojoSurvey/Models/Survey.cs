// namespace dojoSurvey.Models
// {
//     public class Survey
//     {
//         public string name{get; set;}
//         public string dojo{get; set;}
//         public string favorite{get; set;}
//         public string text{get; set;}
//     }
// }