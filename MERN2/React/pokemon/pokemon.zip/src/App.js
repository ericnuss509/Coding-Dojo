import './App.css';
import Index from './component/Index'
import React from 'react'

function App() {
  return (
    <div className="App">
        <Index />
    </div>
  );
}

export default App;
