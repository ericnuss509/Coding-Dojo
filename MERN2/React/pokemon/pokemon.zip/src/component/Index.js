import React, { useState } from "react"



const Index = (e) => {
    const [pokemon, setPokemon] = useState([]);

    const handleClick = (e) => {
        e.preventDefault();
        fetch('https://pokeapi.co/api/v2/pokemon?limit=807')
            .then(response => response.json())
            .then(response => setPokemon(response.results))
    }


    return (
        <>
            <div>
                <input type="submit" value="fetch pokemon" onClick={handleClick} />
            </div>
            {pokemon.map((m, i) => {
                return (
                    <li>{m.name}</li>
                )
            })}
        </>

    )
}
export default Index