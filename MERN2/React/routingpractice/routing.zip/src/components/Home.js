import React from 'react';

const Home = (e) => {
    return(
        <>
            <h1>
                Homepage for Rounting Practice
            </h1>
        </>
    )
}

export default Home